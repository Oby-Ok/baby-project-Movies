```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

```


```python
df = pd.read_csv("Movies Dataset.csv")  

```


```python
df.head()  # Show first 5 rows

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>title</th>
      <th>genres</th>
      <th>original_language</th>
      <th>overview</th>
      <th>popularity</th>
      <th>production_companies</th>
      <th>release_date</th>
      <th>budget</th>
      <th>revenue</th>
      <th>runtime</th>
      <th>status</th>
      <th>tagline</th>
      <th>vote_average</th>
      <th>vote_count</th>
      <th>credits</th>
      <th>keywords</th>
      <th>poster_path</th>
      <th>backdrop_path</th>
      <th>recommendations</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>385687</td>
      <td>Fast X</td>
      <td>Action-Crime-Thriller</td>
      <td>en</td>
      <td>Over many missions and against impossible odds...</td>
      <td>6682.100</td>
      <td>Universal Pictures-Original Film-One Race-Perf...</td>
      <td>2023-05-17</td>
      <td>340000000.0</td>
      <td>6.867000e+08</td>
      <td>142.0</td>
      <td>Released</td>
      <td>The end of the road begins.</td>
      <td>7.331</td>
      <td>1856.0</td>
      <td>Vin Diesel-Michelle Rodriguez-Tyrese Gibson-Lu...</td>
      <td>sequel-revenge-racing-family-cars</td>
      <td>/fiVW06jE7z9YnO4trhaMEdclSiC.jpg</td>
      <td>/4XM8DUTQb3lhLemJC51Jx4a2EuA.jpg</td>
      <td>19603-445954-697843-603692-781009-502356-74735...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>758323</td>
      <td>The Pope's Exorcist</td>
      <td>Horror-Mystery-Thriller</td>
      <td>en</td>
      <td>Father Gabriele Amorth Chief Exorcist of the V...</td>
      <td>5953.227</td>
      <td>Screen Gems-2.0 Entertainment-Jesus &amp; Mary-Wor...</td>
      <td>2023-04-05</td>
      <td>18000000.0</td>
      <td>6.567582e+07</td>
      <td>103.0</td>
      <td>Released</td>
      <td>Inspired by the actual files of Father Gabriel...</td>
      <td>7.433</td>
      <td>545.0</td>
      <td>Russell Crowe-Daniel Zovatto-Alex Essoe-Franco...</td>
      <td>spain-rome italy-vatican-pope-pig-possession-c...</td>
      <td>/9JBEPLTPSm0d1mbEcLxULjJq9Eh.jpg</td>
      <td>/hiHGRbyTcbZoLsYYkO4QiCLYe34.jpg</td>
      <td>713704-296271-502356-1076605-1084225-1008005-9...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>640146</td>
      <td>Ant-Man and the Wasp: Quantumania</td>
      <td>Action-Adventure-Science Fiction</td>
      <td>en</td>
      <td>Super-Hero partners Scott Lang and Hope van Dy...</td>
      <td>4425.387</td>
      <td>Marvel Studios-Kevin Feige Productions</td>
      <td>2023-02-15</td>
      <td>200000000.0</td>
      <td>4.757662e+08</td>
      <td>125.0</td>
      <td>Released</td>
      <td>Witness the beginning of a new dynasty.</td>
      <td>6.507</td>
      <td>2811.0</td>
      <td>Paul Rudd-Evangeline Lilly-Jonathan Majors-Kat...</td>
      <td>hero-ant-sequel-superhero-based on comic-famil...</td>
      <td>/qnqGbB22YJ7dSs4o6M7exTpNxPz.jpg</td>
      <td>/m8JTwHFwX7I7JY5fPe4SjqejWag.jpg</td>
      <td>823999-676841-868759-734048-267805-965839-1033...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>677179</td>
      <td>Creed III</td>
      <td>Drama-Action</td>
      <td>en</td>
      <td>After dominating the boxing world Adonis Creed...</td>
      <td>3994.342</td>
      <td>Metro-Goldwyn-Mayer-Proximity Media-Balboa Pro...</td>
      <td>2023-03-01</td>
      <td>75000000.0</td>
      <td>2.690000e+08</td>
      <td>116.0</td>
      <td>Released</td>
      <td>You can't run from your past.</td>
      <td>7.262</td>
      <td>1129.0</td>
      <td>Michael B. Jordan-Tessa Thompson-Jonathan Majo...</td>
      <td>philadelphia pennsylvania-husband wife relatio...</td>
      <td>/cvsXj3I9Q2iyyIo95AecSd1tad7.jpg</td>
      <td>/5i6SjyDbDWqyun8klUuCxrlFbyw.jpg</td>
      <td>965839-267805-943822-842942-1035806-823999-107...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>502356</td>
      <td>The Super Mario Bros. Movie</td>
      <td>Animation-Family-Adventure-Fantasy-Comedy</td>
      <td>en</td>
      <td>While working underground to fix a water main ...</td>
      <td>3859.926</td>
      <td>Universal Pictures-Illumination-Nintendo</td>
      <td>2023-04-05</td>
      <td>100000000.0</td>
      <td>1.278767e+09</td>
      <td>92.0</td>
      <td>Released</td>
      <td>NaN</td>
      <td>7.764</td>
      <td>4042.0</td>
      <td>Chris Pratt-Charlie Day-Anya Taylor-Joy-Jack B...</td>
      <td>video game-gorilla-plumber-magic mushroom-anth...</td>
      <td>/qNBAXBIQlnOThrVvA6mA2B5ggV6.jpg</td>
      <td>/2klQ1z1fcHGgQPevbEQdkCnzyuS.jpg</td>
      <td>713704-385687-640146-60898-758323-1008005-4935...</td>
    </tr>
  </tbody>
</table>
</div>



## Movie Dataset Overview
This dataset contains information about movies, including:
- **Title**: The name of the movie.
- **Genres**: The categories the movie belongs to (e.g., Action, Comedy, Drama).
- **Release Date**: The date the movie was released.
- **Budget**: The estimated production cost of the movie.
- **Revenue**: The total earnings of the movie.
- **Runtime**: The length of the movie in minutes.
- **Vote Average**: The average user rating for the movie.
- **Production Companies**: The company responsible for producing the movie.

We will analyze trends in genres, revenue, and ratings to better understand the movie industry.


# Data Analysis
### 1. Data Structure


```python
df.info()  # Check column types and missing values
df.describe()  # Summary statistics

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 722796 entries, 0 to 722795
    Data columns (total 20 columns):
     #   Column                Non-Null Count   Dtype  
    ---  ------                --------------   -----  
     0   id                    722796 non-null  int64  
     1   title                 722790 non-null  object 
     2   genres                511934 non-null  object 
     3   original_language     722796 non-null  object 
     4   overview              604198 non-null  object 
     5   popularity            722796 non-null  float64
     6   production_companies  337170 non-null  object 
     7   release_date          670329 non-null  object 
     8   budget                722796 non-null  float64
     9   revenue               722796 non-null  float64
     10  runtime               688346 non-null  float64
     11  status                722796 non-null  object 
     12  tagline               108098 non-null  object 
     13  vote_average          722796 non-null  float64
     14  vote_count            722796 non-null  float64
     15  credits               497689 non-null  object 
     16  keywords              210271 non-null  object 
     17  poster_path           537566 non-null  object 
     18  backdrop_path         222524 non-null  object 
     19  recommendations       34720 non-null   object 
    dtypes: float64(6), int64(1), object(13)
    memory usage: 110.3+ MB
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>runtime</th>
      <th>vote_average</th>
      <th>vote_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>722796.000000</td>
      <td>722796.000000</td>
      <td>7.227960e+05</td>
      <td>7.227960e+05</td>
      <td>6.883460e+05</td>
      <td>722796.000000</td>
      <td>722796.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>526917.587990</td>
      <td>1.807185</td>
      <td>3.924801e+05</td>
      <td>9.776385e+05</td>
      <td>1.989186e+02</td>
      <td>2.443118</td>
      <td>27.610661</td>
    </tr>
    <tr>
      <th>std</th>
      <td>253164.471522</td>
      <td>18.839397</td>
      <td>8.136181e+06</td>
      <td>2.010908e+07</td>
      <td>8.581987e+04</td>
      <td>3.175498</td>
      <td>381.523676</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.000000</td>
      <td>0.600000</td>
      <td>0.000000e+00</td>
      <td>-1.200000e+01</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>328947.750000</td>
      <td>0.600000</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>5.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>533364.500000</td>
      <td>0.600000</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>5.000000e+01</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>737817.250000</td>
      <td>1.290000</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>9.000000e+01</td>
      <td>5.600000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>968161.000000</td>
      <td>6682.100000</td>
      <td>5.000000e+09</td>
      <td>2.920357e+09</td>
      <td>5.050505e+07</td>
      <td>10.000000</td>
      <td>33262.000000</td>
    </tr>
  </tbody>
</table>
</div>



## Dataset Overview  
This dataset contains **722,796 movies** with **20 columns**, covering details like title, genres, budget, revenue, ratings, and production companies. Several columns have missing values, notably **genres, production companies, and release date**.  

### **Key Insights**  
#### **Numerical Summary**  
| Feature       | Min      | Max            | Mean       | Median  |
|--------------|---------|--------------|-----------|--------|
| Popularity   | 0.6     | 6682.1       | 1.81      | 0.6    |
| Budget ($)   | 0       | 5B           | 392,480   | 0      |
| Revenue ($)  | -12     | 2.9B         | 9.77M     | 0      |
| Runtime (min)| 0       | 50,505,000   | 198       | 50     |
| Vote Avg.    | 0       | 10           | 2.44      | 0      |
| Vote Count   | 0       | 33,262       | 27.61     | 0      |

#### **Observations**  
- Many movies have **missing or zero budget and revenue**, affecting analysis.  
- **Popularity is highly skewed**, with a few blockbuster films dominating.  
- **Vote counts are low for most movies**, indicating limited audience engagement.  
- **Extreme runtime values** suggest data entry errors.  

### **Next Steps**  
- **Identify zero values** in key columns.  
- **Filter out extreme outliers** for better insights.  
- **Analyze trends** in revenue, genres, and ratings.  

This dataset is valuable but requires cleaning before deeper analysis.  


### 2. Check for missing data


```python
df.isnull().sum()

```




    id                           0
    title                        6
    genres                  210862
    original_language            0
    overview                118598
    popularity                   0
    production_companies    385626
    release_date             52467
    budget                       0
    revenue                      0
    runtime                  34450
    status                       0
    tagline                 614698
    vote_average                 0
    vote_count                   0
    credits                 225107
    keywords                512525
    poster_path             185230
    backdrop_path           500272
    recommendations         688076
    dtype: int64




```python
pip install matplotlib seaborn

```

    Requirement already satisfied: matplotlib in c:\users\oby\anaconda3\lib\site-packages (3.9.2)
    Requirement already satisfied: seaborn in c:\users\oby\anaconda3\lib\site-packages (0.13.2)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\oby\anaconda3\lib\site-packages (from matplotlib) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\users\oby\anaconda3\lib\site-packages (from matplotlib) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\oby\anaconda3\lib\site-packages (from matplotlib) (4.51.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\oby\anaconda3\lib\site-packages (from matplotlib) (1.4.4)
    Requirement already satisfied: numpy>=1.23 in c:\users\oby\anaconda3\lib\site-packages (from matplotlib) (1.26.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\oby\anaconda3\lib\site-packages (from matplotlib) (24.1)
    Requirement already satisfied: pillow>=8 in c:\users\oby\anaconda3\lib\site-packages (from matplotlib) (10.4.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\oby\anaconda3\lib\site-packages (from matplotlib) (3.1.2)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\oby\anaconda3\lib\site-packages (from matplotlib) (2.9.0.post0)
    Requirement already satisfied: pandas>=1.2 in c:\users\oby\anaconda3\lib\site-packages (from seaborn) (2.2.2)
    Requirement already satisfied: pytz>=2020.1 in c:\users\oby\anaconda3\lib\site-packages (from pandas>=1.2->seaborn) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\oby\anaconda3\lib\site-packages (from pandas>=1.2->seaborn) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\oby\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.
    

# Visualizations


```python
# First, split genres by hyphen and expand into multiple rows
genres_expanded = df['genres'].str.split('-', expand=True).stack().reset_index(level=1, drop=True)
genres_expanded.name = 'genre'

# Now plot the counts of each genre
plt.figure(figsize=(10,6))
sns.countplot(y=genres_expanded, order=genres_expanded.value_counts().index)
plt.title("Number of Movies per Genre")
plt.xlabel("Count")
plt.ylabel("Genre")
plt.show()



```


    
![png](output_11_0.png)
    


### Number of Movies per Genre
The visualization shows that the most popular genre in our dataset is Action, followed by Drama and Comedy. This suggests that action movies dominate the industry


```python
plt.figure(figsize=(10,6))
sns.lineplot(x="release_year", y="revenue", data=df)
plt.title("Box Office Revenue Trends Over Time")
plt.xlabel("Release Year")
plt.ylabel("Box Office Revenue ($)")
plt.show()


```


    
![png](output_13_0.png)
    


### Box Office Revenue Over Time
Over time, movie revenue has increased significantly, indicating growth in the film industry.
There are some fluctuations, possibly due to economic trends or streaming services.


```python
plt.figure(figsize=(8,5))
sns.histplot(df["vote_average"], bins=10, kde=True)
plt.title("Distribution of Movie Ratings")
plt.xlabel("Rating")
plt.ylabel("Frequency")
plt.show()

```


    
![png](output_15_0.png)
    


### Distribution of Movie Ratings
The majority of movies have ratings between 6 and 8, with very few receiving a perfect 10. 
This suggests that most movies are rated positively, but only a handful are considered outstanding.

# Key Findings
1. **Drama, Documentary and Comedy** are the most popular genres.
2. **Box office revenue** has increased over time, showing industry growth.
4. The **distribution of Movie Ratings** is heavily skewed, with most movies having a rating of 0 (indicating missing or unrated films),
   while rated movies typically fall between 5 and 7, with very few achieving near-perfect scores (9-10).



```python

```
